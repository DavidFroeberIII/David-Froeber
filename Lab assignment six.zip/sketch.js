function setup() {
  createCanvas(500, 500);
  
}

function draw() {
  background(220);
  background(255,255,255);
quad(100,100,400,100,400,400,100,400);
  quad(115,115,385,115,385,300,115,300);
  line(225,100,150,50);
  line(275,100,350,50);
  ellipse(250,350,50);
  rect(115,325,75,50);
  rect(310,325,75,50);
  translate(30, 20);
  scale(0.5);
rotate(PI / 3.0);
  ellipse(0, 50, 33, 33); 

push(); 
strokeWeight(10);
fill(204, 153, 0);
translate(50, 0);
ellipse(0, 50, 33, 33); 
pop(); 

ellipse(100, 50, 33, 33);
  
  let x = 10;
print('The value of x is ' + x);
  
  ellipse(500,0,50,50);
  
}
