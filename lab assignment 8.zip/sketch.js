let art;
let among;

function preload(){
   art = loadImage('art.jpg');
 among= loadImage('among us.gif');

}


 


function setup(){
createCanvas (480,400);
textFont("Arial");
 
}

function draw() {
  background(220);
  image(art, 0,0, mouseX,mouseY);
  text(32);
  text("hi",300,300);
  image(among,100,100,100,100);
}